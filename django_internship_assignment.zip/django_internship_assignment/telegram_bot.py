from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
from api.models import TelegramUser
import django
import os

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'project.settings')
django.setup()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    username = update.effective_user.username
    TelegramUser.objects.create(username=username)
    await update.message.reply_text(f"Welcome, {username}!")

app = ApplicationBuilder().token("YOUR_TELEGRAM_BOT_TOKEN").build()
app.add_handler(CommandHandler("start", start))
app.run_polling()
