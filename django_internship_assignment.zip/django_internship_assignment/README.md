# Django REST + Celery + Telegram Bot Project

## Setup Instructions
1. Clone the repo and install dependencies:
```
pip install -r requirements.txt
```

2. Add a `.env` file:
```
SECRET_KEY=your-secret-key
DEBUG=True
```

3. Run migrations:
```
python manage.py migrate
```

4. Run the server:
```
python manage.py runserver
```

5. Start Celery:
```
celery -A project worker --loglevel=info
```

6. Run Telegram bot:
```
python telegram_bot.py
```

## API Endpoints
- `/api/public/`
- `/api/protected/` (JWT token required)
